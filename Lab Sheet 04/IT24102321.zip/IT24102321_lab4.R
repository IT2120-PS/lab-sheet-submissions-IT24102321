setwd("C:\\Users\\it24102321\\Desktop\\IT24102321")
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

str(branch_data)
boxplot(branch_data$Sales_X1, main = "Boxplot of Sales", Outline = "TRUE", outpch = 8 ,horizontal =TRUE)

# Five-number summary and IQR for Advertising
summary(branch_data$Advertising_X2)   # Five-number summary
IQR(branch_data$Advertising_X2)       # Interquartile range


find_outliers <- function(x){
  Q1 <- quantile(x , 0.25, na.rm = TRUE)
  Q3 <- quantile(x , 0.75 , na.rm = TRUE)
  IQR_value <- Q3-Q1
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  
  outliers <- x[x<lower_bound | x> upper_bound]
  return(outliers)
}
